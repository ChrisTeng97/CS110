#ifndef RISCV_H
#define RISCV_H

#include "part1/assembler.h"
#include "part2/emulator.h"
#include "types.h"
#include "utils.h"

#endif