#ifndef _TF_CARD_H_
#define _TF_CARD_H_

#include "gd32v_pjt_include.h"
#include "diskio.h"
#include "ff.h"
#include "systick.h"

#endif
